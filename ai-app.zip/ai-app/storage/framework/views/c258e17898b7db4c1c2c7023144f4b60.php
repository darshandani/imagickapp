<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>


        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>


        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

        <!-- Styles -->
        <style>
            
        </style>
    </head>

    <body>
        <div class="container">
            
            <div class="row mt-5">
                <div class="col-md-12">
                    <form id="getImageForm">
                        <div class="row">
                            <div class="col-md-3 offset-2">
                                <label for="keyword" class="fw-bold">Keyword :</label>
                                <input type="text" name="keyword" class="form-control" id="keyword" placeholder="Serach">
                            </div>
                            <div class="col-md-3">
                                <label for="caption" class="fw-bold">Caption :</label>
                                <input type="text" name="caption" class="form-control" id="caption" placeholder="Serach">
                            </div>
                            <div class="col-md-2">
                                <a herf="javascript:void(0);" id="submitBtn" class="btn btn-success mt-4">Get Image</a> 
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            
            <div class="row mt-5">
                <div class="col-md-12">
                    <?php echo $__env->make("notifications", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

            
            <div class="row mt-5 g-1 text-center" id="output-div">
                <div class="col-md-4 offset-4">
                    <h2 class="text-warning">Search and Get Image</h2>
                </div>
            </div>

        </div>
    </body>

    <script>
        $(document).ready(function(){
            $("#getImageForm").on("click",'#submitBtn',function(){
                var keyword = $("#keyword").val();
                var caption = $("#caption").val();
                var url = '<?php echo e(route("image.generate")); ?>';
                $.ajax({
                    type: "POST",
                    url: url,
                    datatype: "json",
                    data: {
                        '_token': '<?php echo csrf_token(); ?>',
                        'keyword': keyword,
                        'caption': caption
                    },
                    beforeSend: function () {

                    },
                    success: function(resp) {
                        //alert(resp.length);
                        if(resp.length){
                            var html = ''; 
                            Object.keys(resp).forEach(function(key, url) {
                                //alert(resp[key]);
                                html += '<div class="col-md-3">\
                                        <embed src="'+resp[key]+'" width="270" height="270" alt="" class="rounded-3" />\
                                </div>'
                            });

                            $('#output-div').html(html);

                            $('.alert-success').children(".msg-content").html("Image Found Succesfully.");
                            $('.alert-success').removeClass("d-none").show();

                        }else{
                            $('.alert-danger').children(".msg-content").html("Image is not found.");
                            $('.alert-danger').removeClass("d-none").show();
                        }
                    },
                    error: function(e) {

                    }
                });
            });
        });
    </script>

</html>
<?php /**PATH C:\xampp\htdocs\ai-app\resources\views/image.blade.php ENDPATH**/ ?>