<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;

use Imagick;
use ImagickDraw;
use ImagickPixel;


class ImageController extends Controller
{
    public function index()
    {
        return view("image");
    }


    public function generateImage(Request $request)
    {
        $request = $request->all();

        $api_Key = env("PIXEL_API_KEY");
        $key_word = $request['keyword'] ?? 'AI';

        $client = new Client();

        try {
            $response = $client->get('https://api.pexels.com/v1/search?query='.$key_word, [
                'headers' => [
                    'Authorization' => "$api_Key",
                ],
            ]);
            if ($response->getStatusCode() === 200) {
                $allPhotos = json_decode($response->getBody());
                $photos = $allPhotos->photos;
                

                $data = [];
                foreach($photos as $url){
                    $data[] = $url->src->original;
                }

                return response()->json($data);
                
            }
        } catch (\Exception $e) {
            return response()->json([$e]);
        }

        return response()->json([]);
    }
}
